import React from 'react'

const Visual = () => {
  return (
    <div>Visual</div>
  )
}

export default Visual