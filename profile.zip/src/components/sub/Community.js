import React from 'react'
import Layout from '../common/Layout'

const Community = () => {
  return (
    <Layout title={'Community'}>Community</Layout>
  )
}

export default Community