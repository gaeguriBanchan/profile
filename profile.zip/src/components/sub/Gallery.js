import React from 'react'
import Layout from '../common/Layout'

const Gallery = () => {
  return (
    <Layout title={'Gallery'}>Gallery</Layout>
  )
}

export default Gallery