import React from 'react'
import Layout from '../common/Layout'

const Location = () => {
  return (
    <Layout title={'Location'}>Location</Layout>
  )
}

export default Location