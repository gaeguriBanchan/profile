import React from 'react'
import Layout from '../common/Layout'

const Department = () => {
  return (
    <Layout title={'Department'}>Department</Layout>
  )
}

export default Department