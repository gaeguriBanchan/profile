import React from 'react'
import Layout from '../common/Layout'

const Youtube = () => {
  return (
    <Layout title={'Youtube'}>Youtube</Layout>
  )
}

export default Youtube