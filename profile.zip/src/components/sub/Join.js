import React from 'react'
import Layout from '../common/Layout'

const Join = () => {
  return (
    <Layout title={'Join'}>Join</Layout>
  )
}

export default Join